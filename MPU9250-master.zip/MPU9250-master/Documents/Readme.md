Various documents I have collected over the years regarding operation and use of the MPU9250
